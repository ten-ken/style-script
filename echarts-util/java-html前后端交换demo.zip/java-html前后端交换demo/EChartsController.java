/******************************************************************************
 *
 * 版权所有：安徽匠桥电子信息有限公司
 *
 ******************************************************************************
 * 注意：本内容仅限于安徽匠桥电子信息有限公司内部使用，禁止转发
 *****************************************************************************/
package com.jiangqiao.erp.base.controller;

import com.jiangqiao.core.controller.BaseController;
import com.jiangqiao.erp.base.entity.TMessageInfo;
import com.jiangqiao.erp.pm.entity.TProductionPlanInfo;
import com.jiangqiao.erp.pm.mapper.TProductionPlanInfoMapper;
import com.jiangqiao.erp.psi.entity.TOrderDetail;
import com.jiangqiao.erp.psi.mapper.TOrderInfoMapper;
import com.jiangqiao.sys.common.util.EChartsUtils;
import com.jiangqiao.sys.common.util.EchartPo;
import com.jiangqiao.sys.common.util.EchartSeries;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.math.BigDecimal;
import java.util.*;

/**
 * <ul>
 * <li>Title: 匠桥ERP系统-EChartsController</li>
 * <li>Description: echarts控制层 </li>
 * <li>Copyright: Copyright (c) 2018</li>
 * <li>Company: http://www.jiangqiaotech.com/</li>
 * </ul>
 *
 * @author swc
 * @version 匠桥ERP系统V1.0
 * @date 2019/12/3 0003 下午 15:08
 */

@Controller
@RequestMapping("/echarts")
public class EChartsController extends BaseController {

    private final String[] columnNames ={"巴西","印尼","美国","印度","中国"};
    private final Long[] columnValues ={69L, 70L,76L, 80L,99L};

    @Autowired
    private TProductionPlanInfoMapper tProductionPlanInfoMapper;

    @Autowired
    private TOrderInfoMapper tOrderInfoMapper;



    /**
     * 功能描述: 柱状图
     * @return: com.jiangqiao.core.message.Message
     * @author: swc
     * @date: 2019/12/3 0003 下午 15:09
    */     
    @RequestMapping("bar.jiangqiao")
    @ResponseBody
    public Map<String,List<Object>> column() throws Exception {
        //        数据开始区
        List<TMessageInfo> messageInfoList =new ArrayList<TMessageInfo>();
        TMessageInfo t1 =null;
        for(int i=0;i<columnNames.length;i++){
            t1 =new TMessageInfo();
            t1.setMaterialId(columnValues[i]);
            t1.setMaterialName(columnNames[i]);
            messageInfoList.add(t1);
        }
        //        数据结束区
        Map<String, List<Object>> barChart = EChartsUtils.getBarChart(messageInfoList, "materialName", "materialId");
        return barChart;
    }



    /**
     * 功能描述: 柱状图
     * @return: com.jiangqiao.core.message.Message
     * @author: swc
     * @date: 2019/12/3 0003 下午 15:09
     */
    @RequestMapping("foldline.jiangqiao")
    @ResponseBody
    public Map<String,List<Object>> foldline(String type) throws Exception {
        TProductionPlanInfo tProductionPlanInfo =new TProductionPlanInfo();
        List<TProductionPlanInfo> list=tProductionPlanInfoMapper.initEcharts(tProductionPlanInfo);

        Object[] legends ={"计划数量","已完成","未完成"};
        Object[] fields ={"nums","newOverNums","surplusNums"};

        List<BigDecimal> l1 =new ArrayList<BigDecimal>();
        List<BigDecimal> l2 =new ArrayList<BigDecimal>();
        List<BigDecimal> l3 =new ArrayList<BigDecimal>();

        Map<String, List<Object>> barChart = EChartsUtils.getECharOptionsToFoldLine(type,list, "planNo",legends,fields,l1,l2,l3);
        return barChart;
    }




    /**
     * 功能描述: 柱状图
     * @return: com.jiangqiao.core.message.Message
     * @author: swc
     * @date: 2019/12/3 0003 下午 15:09
     */
    @RequestMapping("circle.jiangqiao")
    @ResponseBody
    public Map<String,List<Object>> circle(TOrderDetail tOrderDetail) throws Exception {
        List<EchartPo> tOrderInfoList = tOrderInfoMapper.regionSell(tOrderDetail);
        Map<String, List<Object>> map = EChartsUtils.getECharOptionsToCircle(tOrderInfoList, "name","value");
        return map;
    }


}
