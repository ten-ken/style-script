/******************************************************************************
 *
 * 版权所有：安徽匠桥电子信息有限公司
 *
 ******************************************************************************
 * 注意：本内容仅限于安徽匠桥电子信息有限公司内部使用，禁止转发
 *****************************************************************************/
package com.jiangqiao.sys.common.util;

import com.jiangqiao.core.utils.ReflectUtils;
import com.jiangqiao.erp.base.entity.TMessageInfo;
import com.jiangqiao.util.EmptyUtil;
import org.apache.poi.ss.formula.functions.T;

import java.math.BigDecimal;
import java.util.*;

/**
 * <ul>
 * <li>Title: 匠桥ERP系统-EChartsUtils</li>
 * <li>Description: TODO </li>
 * <li>Copyright: Copyright (c) 2018</li>
 * <li>Company: http://www.jiangqiaotech.com/</li>
 * </ul>
 *
 * @author swc
 * @version 匠桥ERP系统V1.0
 * @date 2019/12/3 0003 下午 17:25
 */
public class EChartsUtils {

    public static final String TYPEFOLDLINE ="line";

    public static final String TYPEBAR ="bar";

    /**
     * 功能描述: 获取echarts图==》最简单的柱状图  配置  y轴 [巴西,中国,韩国]  x轴[25,32,56]
     * @param list
     * @param nameField
     * @param valueField
     * @return: java.util.Map<java.lang.String,java.util.List<java.lang.Object>> 
     * @author: swc
     * @date: 2019/12/3 0003 下午 17:26
     */
    public static <T> Map<String,List<Object>> getBarChart(List<T> list, String nameField, String valueField)throws Exception {
        List<Object> namesList =new ArrayList<Object>();
        List<Object> valuesList =new ArrayList<Object>();

        Map<String,List<Object>> map =new HashMap<String,List<Object>>();

        for(T t:list){
            namesList.add(ReflectUtils.getFieldValue(t,nameField));
            valuesList.add(ReflectUtils.getFieldValue(t,valueField));
        }
        map.put("values",valuesList);
        map.put("names",namesList);
        return map;
    }

//    /**
//     * 功能描述: 获取多个Series的echarts配置信息---其实此处 只会处理x轴的name 意味着y轴的value需要具体处理
//     * @param list
//     * @param nameField
//     * @param valueField
//     * @return: java.util.Map<java.lang.String,java.util.List<java.lang.Object>>
//     * @author: swc
//     * @date: 2019/12/3 0003 下午 17:35
//     */
//    public static <T> Map<String,List<Object>> getECharOptions(List<T> list, String nameField, String valueField)throws Exception {
//        if(!EmptyUtil.isNullOrEmpty(valueField)){
//            return getBarChart(list,nameField,valueField);
//        }
//        List<Object> namesList =new ArrayList<Object>();
//
//        Map<String,List<Object>> map =new HashMap<String,List<Object>>();
//
//        for(T t:list){
//            namesList.add(ReflectUtils.getFieldValue(t,nameField));
//        }
//        map.put("names",namesList);
//        return map;
//    }

    /**
     * 功能描述: 生成折线图或者柱状图的属性
     * @param type "bar"==>柱状图  or "line" 折线图
     * @param list
     * @param nameField x轴需要对应的值 （实体的属性名)
     * @param legends
     * @param fields y轴需要对应的值 （单个serie对应的data数据  实体对应的属性名)
     * @param saveList 每个list和fields的值是一一对应的  
     * @return: java.util.Map<java.lang.String,java.util.List<java.lang.Object>> 
     * @author: swc
     * @date: 2019/12/4 0004 下午 13:47
    */ 
    public static <T>Map<String,List<Object>> getECharOptionsToFoldLine(String type,List<T> list, String nameField, Object[] legends, Object[] fields, List ...saveList) {
        List<Object> namesList =new ArrayList<Object>();

        Map<String,List<Object>> map =new HashMap<String,List<Object>>();
        Object obj =null;
        for(T t:list){
            namesList.add(ReflectUtils.getFieldValue(t,nameField));
            for(int ind=0;ind<fields.length;ind++){
               obj = ReflectUtils.getFieldValue(t,(String)fields[ind]);
               obj = EmptyUtil.isNullOrEmpty(obj)?0:obj;
               saveList[ind].add(obj);
            }
        }

        List<Object> backList =new ArrayList<Object>();
        EchartSeries<Long> echartSeries =null;
        for(int ind=0;ind<fields.length;ind++){
            echartSeries =new EchartSeries<Long>();
            echartSeries.setName((String)legends[ind]);
            echartSeries.setType(type);
//             echartSeries.setStack("总量");
            echartSeries.setData(saveList[ind]);
            backList.add(echartSeries);
        }

        map.put("names",namesList);
        map.put("values",backList);
        //new ArrayList<Object>(Arrays.asList(legends))
        map.put("legends",Arrays.asList(legends));

        return map;
    }


    /**
     * 功能描述: 生成饼状图的属性
     * @param list
     * @param nameField
     * @param circleVField list里面对象的属性值  代表该饼状图区域的数值
     * @return: java.util.Map<java.lang.String,java.util.List<java.lang.Object>> 
     * @author: swc
     * @date: 2019/12/4 0004 下午 13:51
    */ 
    public static <T>Map<String,List<Object>> getECharOptionsToCircle(List<T> list, String nameField, String circleVField) {
        List<Object> namesList =new ArrayList<Object>();
        Map<String,List<Object>> map =new HashMap<String,List<Object>>();

        List<Object> backList =new ArrayList<Object>();
        EchartSeries<Long> echartSeries =null;

        Object obj=null;
        List<Object> legends =new ArrayList<Object>();

        for(int ind=0;ind<list.size();ind++){
            namesList.add(ReflectUtils.getFieldValue(list.get(ind),nameField));
            echartSeries =new EchartSeries<Long>();
            echartSeries.setName((String)ReflectUtils.getFieldValue(list.get(ind),nameField));
            obj = ReflectUtils.getFieldValue(list.get(ind),circleVField);
            obj = EmptyUtil.isNullOrEmpty(obj)?0:obj;
            echartSeries.setValue(new BigDecimal(obj.toString()));
            backList.add(echartSeries);
            legends.add((String)ReflectUtils.getFieldValue(list.get(ind),nameField));
        }

        map.put("names",namesList);
        map.put("values",backList);
        map.put("legends",legends);
        return map;
    }
}
